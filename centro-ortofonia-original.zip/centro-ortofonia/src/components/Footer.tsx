import Link from "next/link";
import { Facebook, Instagram, Linkedin, Twitter, Phone, Mail, MapPin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-accent text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center">
                <span className="text-white font-bold text-lg">CD</span>
              </div>
              <div>
                <h3 className="font-bold text-lg">Centro Darbouazza</h3>
                <p className="text-xs text-gray-300">Ortofonía Especializada</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm">
              Líderes en el tratamiento de trastornos del habla y lenguaje,
              comprometidos con el bienestar de nuestros pacientes.
            </p>
            <div className="flex space-x-3 mt-4">
              <a href="#" className="w-10 h-10 bg-white/10 hover:bg-primary rounded-full flex items-center justify-center transition-colors">
                <Facebook size={20} />
              </a>
              <a href="https://www.instagram.com/orthophoniste__darbouazza/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/10 hover:bg-primary rounded-full flex items-center justify-center transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 hover:bg-primary rounded-full flex items-center justify-center transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 hover:bg-primary rounded-full flex items-center justify-center transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#nosotros" className="text-gray-300 hover:text-primary transition-colors">
                  Sobre Nosotros
                </Link>
              </li>
              <li>
                <Link href="#servicios" className="text-gray-300 hover:text-primary transition-colors">
                  Servicios
                </Link>
              </li>
              <li>
                <Link href="#especialistas" className="text-gray-300 hover:text-primary transition-colors">
                  Nuestro Equipo
                </Link>
              </li>
              <li>
                <Link href="#formaciones" className="text-gray-300 hover:text-primary transition-colors">
                  Formaciones
                </Link>
              </li>
              <li>
                <Link href="#cita" className="text-gray-300 hover:text-primary transition-colors">
                  Reservar Cita
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-bold text-lg mb-4">Especialidades</h3>
            <ul className="space-y-2">
              <li className="text-gray-300 text-sm">Trastornos del Lenguaje</li>
              <li className="text-gray-300 text-sm">Trastornos del Habla</li>
              <li className="text-gray-300 text-sm">Dificultades de Aprendizaje</li>
              <li className="text-gray-300 text-sm">Trastornos de la Voz</li>
              <li className="text-gray-300 text-sm">Deglución y Alimentación</li>
              <li className="text-gray-300 text-sm">Comunicación y TEA</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-bold text-lg mb-4">Contacto</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin size={18} className="text-primary mt-1" />
                <p className="text-gray-300 text-sm">
                  Rue Georges Sand, Résidence Benber,<br />
                  Immeuble A, Étage 1, Casablanca
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={18} className="text-primary" />
                <div>
                  <p className="text-gray-300 text-sm">+212 520 66 89 67</p>
                  <p className="text-gray-300 text-sm">+212 662 562 687</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={18} className="text-primary" />
                <p className="text-gray-300 text-sm">contacto@centrodarbouazza.ma</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 text-sm text-center md:text-left">
              © 2025 Centro Darbouazza. Todos los derechos reservados.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="#" className="text-gray-300 hover:text-primary text-sm transition-colors">
                Política de Privacidad
              </Link>
              <Link href="#" className="text-gray-300 hover:text-primary text-sm transition-colors">
                Términos y Condiciones
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

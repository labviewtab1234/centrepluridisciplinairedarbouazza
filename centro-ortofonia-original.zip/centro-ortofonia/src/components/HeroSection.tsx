"use client";

import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Phone, MapPin } from "lucide-react";

const HeroSection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: "Bienvenidos al Centro Darbouazza",
      subtitle: "Especialistas en Ortofonía y Terapia del Lenguaje",
      description: "Tu destino de confianza para una atención integral y personalizada en trastornos del habla y lenguaje",
      buttonText: "Reservar Consulta",
      bgColor: "bg-gradient-to-br from-primary/90 to-primary-dark/90"
    },
    {
      title: "Profesionales Especializados",
      subtitle: "Más de 15 años de experiencia",
      description: "Un equipo multidisciplinario comprometido con tu bienestar y progreso comunicativo",
      buttonText: "Conoce al Equipo",
      bgColor: "bg-gradient-to-br from-primary-dark/90 to-primary-darker/90"
    },
    {
      title: "Terapias Personalizadas",
      subtitle: "Adaptadas a cada paciente",
      description: "Programas individualizados para niños, adolescentes y adultos con resultados comprobados",
      buttonText: "Ver Servicios",
      bgColor: "bg-gradient-to-br from-primary-darker/90 to-primary-darkest/90"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  return (
    <section className="relative h-[600px] lg:h-[700px] overflow-hidden">
      {/* Background Image with Overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=2070')`,
        }}
      />

      {/* Slides */}
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 flex items-center justify-center transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className={`absolute inset-0 ${slide.bgColor}`} />
          <div className="relative z-10 container mx-auto px-4 text-center text-white">
            <h1 className="text-4xl lg:text-6xl font-bold mb-4 animate-fadeIn">
              {slide.title}
            </h1>
            <h2 className="text-xl lg:text-3xl mb-6 animate-slideInLeft">
              {slide.subtitle}
            </h2>
            <p className="text-lg lg:text-xl mb-8 max-w-3xl mx-auto animate-slideInRight">
              {slide.description}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fadeIn">
              <button className="bg-white text-primary hover:bg-gray-100 px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105">
                {slide.buttonText}
              </button>
              <a
                href="tel:+212662562687"
                className="bg-secondary hover:bg-secondary/90 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
              >
                <Phone size={20} />
                +212 662 562 687
              </a>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-3 rounded-full transition-all duration-300"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-3 rounded-full transition-all duration-300"
      >
        <ChevronRight size={24} />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide
                ? "bg-white w-8"
                : "bg-white/50 hover:bg-white/70"
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroSection;

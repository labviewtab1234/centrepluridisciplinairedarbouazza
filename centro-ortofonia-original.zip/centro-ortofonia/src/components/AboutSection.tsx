import { CheckCircle, Users, Award, Heart } from "lucide-react";

const AboutSection = () => {
  return (
    <section id="nosotros" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="order-2 lg:order-1">
            <div className="text-center lg:text-left mb-8">
              <span className="text-primary font-semibold text-sm uppercase tracking-wider">
                EFICACIA Y DIVERSIDAD
              </span>
              <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mt-2 mb-6">
                El Centro En Resumen
              </h2>
            </div>

            <p className="text-gray-700 leading-relaxed mb-6">
              El Centro Darbouazza de Ortofonía es una institución especializada dedicada a la evaluación,
              diagnóstico y tratamiento de los trastornos del habla, lenguaje, voz y deglución.
              Nuestro compromiso es brindar atención integral a pacientes de todas las edades,
              desde niños hasta adultos mayores.
            </p>

            <p className="text-gray-700 leading-relaxed mb-8">
              Con más de 15 años de experiencia, nuestro centro se ha consolidado como referente
              en el campo de la ortofonía en la región. Trabajamos con un enfoque multidisciplinario,
              colaborando estrechamente con otros profesionales de la salud para garantizar
              los mejores resultados terapéuticos.
            </p>

            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              <div className="flex items-start space-x-3">
                <CheckCircle className="text-primary mt-1" size={20} />
                <div>
                  <h4 className="font-semibold text-gray-900">Evaluación Integral</h4>
                  <p className="text-sm text-gray-600">Diagnóstico preciso y personalizado</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Users className="text-primary mt-1" size={20} />
                <div>
                  <h4 className="font-semibold text-gray-900">Equipo Especializado</h4>
                  <p className="text-sm text-gray-600">Profesionales certificados y experimentados</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Award className="text-primary mt-1" size={20} />
                <div>
                  <h4 className="font-semibold text-gray-900">Métodos Innovadores</h4>
                  <p className="text-sm text-gray-600">Técnicas actualizadas y basadas en evidencia</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Heart className="text-primary mt-1" size={20} />
                <div>
                  <h4 className="font-semibold text-gray-900">Atención Personalizada</h4>
                  <p className="text-sm text-gray-600">Terapias adaptadas a cada paciente</p>
                </div>
              </div>
            </div>

            <p className="text-gray-700 leading-relaxed">
              Nuestro centro ofrece un ambiente cálido y acogedor, especialmente diseñado
              para que nuestros pacientes se sientan cómodos y motivados durante su proceso
              terapéutico. Contamos con instalaciones modernas y material didáctico
              especializado para optimizar cada sesión de terapia.
            </p>
          </div>

          {/* Image */}
          <div className="order-1 lg:order-2">
            <div className="relative">
              <div className="absolute -top-4 -right-4 w-72 h-72 bg-primary/10 rounded-full -z-10" />
              <div className="absolute -bottom-4 -left-4 w-64 h-64 bg-secondary/10 rounded-full -z-10" />
              <img
                src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=2070"
                alt="Centro de Ortofonía"
                className="rounded-lg shadow-xl w-full"
              />
              <div className="absolute bottom-6 left-6 bg-white rounded-lg shadow-lg p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-white font-bold">15+</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Años de Experiencia</p>
                    <p className="text-sm text-gray-600">Transformando vidas</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;

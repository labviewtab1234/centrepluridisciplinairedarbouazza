"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react";

const TestimonialsSection = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      name: "María González",
      role: "Madre de paciente",
      content: "El Centro Darbouazza ha sido fundamental en el desarrollo del lenguaje de mi hijo. El equipo es increíblemente profesional y dedicado. En solo 6 meses hemos visto avances que no imaginábamos posibles.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=2070"
    },
    {
      name: "Ahmed Benslimane",
      role: "Padre de paciente",
      content: "Mi hija tenía dificultades severas con la pronunciación. Gracias al tratamiento personalizado y la paciencia del equipo, ahora habla con claridad y confianza. Estamos eternamente agradecidos.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1974"
    },
    {
      name: "Fatima El Amrani",
      role: "Paciente adulta",
      content: "Después de un accidente, perdí parte de mi capacidad del habla. El centro me devolvió la esperanza y, con terapia constante, he recuperado mi voz. Son verdaderos profesionales.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1961"
    },
    {
      name: "Carlos Rodríguez",
      role: "Educador",
      content: "Como profesor, la formación que recibí en el centro me ha dado herramientas invaluables para apoyar a mis estudiantes con dificultades del lenguaje. Altamente recomendado.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=2070"
    },
    {
      name: "Laila Mansouri",
      role: "Madre de paciente",
      content: "El ambiente cálido y acogedor del centro hace que mi hijo siempre quiera venir a sus sesiones. Los resultados han superado nuestras expectativas. Gracias por todo su apoyo.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1976"
    }
  ];

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-20 bg-primary text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">
            Testimonios de Pacientes
          </h2>
          <p className="text-white/80 max-w-3xl mx-auto">
            Las historias de éxito de nuestros pacientes son nuestra mayor motivación
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <Quote className="absolute -top-4 -left-4 w-16 h-16 text-white/20" />

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 md:p-12">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <img
                  src={testimonials[currentTestimonial].image}
                  alt={testimonials[currentTestimonial].name}
                  className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover border-4 border-white/20"
                />

                <div className="flex-1 text-center md:text-left">
                  <div className="flex justify-center md:justify-start mb-4">
                    {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>

                  <p className="text-lg md:text-xl mb-6 italic">
                    "{testimonials[currentTestimonial].content}"
                  </p>

                  <div>
                    <h4 className="font-bold text-xl">
                      {testimonials[currentTestimonial].name}
                    </h4>
                    <p className="text-white/70">
                      {testimonials[currentTestimonial].role}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={prevTestimonial}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 bg-white/20 hover:bg-white/30 p-3 rounded-full transition-all duration-300"
            >
              <ChevronLeft size={24} />
            </button>
            <button
              onClick={nextTestimonial}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 bg-white/20 hover:bg-white/30 p-3 rounded-full transition-all duration-300"
            >
              <ChevronRight size={24} />
            </button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center space-x-2 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTestimonial(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentTestimonial
                    ? "bg-white w-8"
                    : "bg-white/50 hover:bg-white/70"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;

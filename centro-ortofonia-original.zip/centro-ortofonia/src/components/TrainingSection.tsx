import { GraduationCap, Users, Calendar, Award } from "lucide-react";

const TrainingSection = () => {
  const trainings = [
    {
      title: "Formación para Padres",
      description: "Talleres especializados para padres y cuidadores sobre estimulación del lenguaje y estrategias de apoyo en casa.",
      duration: "8 sesiones",
      participants: "Grupos de 10-15 padres",
      icon: Users,
      topics: [
        "Desarrollo normal del lenguaje",
        "Señales de alerta",
        "Actividades de estimulación",
        "Manejo de conductas"
      ]
    },
    {
      title: "Capacitación Docente",
      description: "Programas de formación para educadores sobre detección temprana y apoyo a estudiantes con dificultades del lenguaje.",
      duration: "16 horas",
      participants: "Instituciones educativas",
      icon: GraduationCap,
      topics: [
        "Identificación de trastornos",
        "Adaptaciones curriculares",
        "Estrategias en el aula",
        "Trabajo colaborativo"
      ]
    },
    {
      title: "Workshops Profesionales",
      description: "Seminarios y talleres para profesionales de la salud sobre últimas técnicas y avances en ortofonía.",
      duration: "Variable",
      participants: "Profesionales de la salud",
      icon: Award,
      topics: [
        "Nuevas metodologías",
        "Casos clínicos",
        "Investigación aplicada",
        "Certificación continua"
      ]
    },
    {
      title: "Cursos Online",
      description: "Formación a distancia con contenido especializado y seguimiento personalizado para profesionales y familias.",
      duration: "Flexible",
      participants: "Abierto",
      icon: Calendar,
      topics: [
        "Módulos interactivos",
        "Videos demostrativos",
        "Material descargable",
        "Certificación digital"
      ]
    }
  ];

  return (
    <section id="formaciones" className="py-20 bg-gradient-to-br from-primary/5 to-secondary/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">
            DESARROLLO Y CAPACITACIÓN
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mt-2 mb-4">
            Formación Evolutiva
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Comprometidos con la educación continua, ofrecemos programas de formación
            para padres, educadores y profesionales de la salud
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {trainings.map((training, index) => {
            const Icon = training.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300"
              >
                <div className="bg-gradient-to-r from-primary to-primary-dark p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                        <Icon className="text-white" size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-white">
                          {training.title}
                        </h3>
                        <p className="text-white/80 text-sm">
                          {training.duration} | {training.participants}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <p className="text-gray-600 mb-4">
                    {training.description}
                  </p>

                  <h4 className="font-semibold text-gray-900 mb-3">Contenido del programa:</h4>
                  <ul className="space-y-2">
                    {training.topics.map((topic, idx) => (
                      <li key={idx} className="flex items-center text-gray-700">
                        <span className="w-2 h-2 bg-primary rounded-full mr-3" />
                        {topic}
                      </li>
                    ))}
                  </ul>

                  <button className="mt-6 w-full bg-primary/10 hover:bg-primary hover:text-white text-primary px-4 py-2 rounded-lg transition-all duration-300 font-medium">
                    Más Información
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 bg-white rounded-xl shadow-lg p-8">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                ¿Por qué elegir nuestras formaciones?
              </h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 mr-3 text-sm">✓</span>
                  <span className="text-gray-700">Contenido actualizado basado en evidencia científica</span>
                </li>
                <li className="flex items-start">
                  <span className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 mr-3 text-sm">✓</span>
                  <span className="text-gray-700">Formadores expertos con amplia experiencia clínica</span>
                </li>
                <li className="flex items-start">
                  <span className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 mr-3 text-sm">✓</span>
                  <span className="text-gray-700">Material didáctico y recursos prácticos incluidos</span>
                </li>
                <li className="flex items-start">
                  <span className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 mr-3 text-sm">✓</span>
                  <span className="text-gray-700">Certificación oficial al completar el programa</span>
                </li>
              </ul>
            </div>
            <div className="text-center">
              <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl p-8">
                <h4 className="text-3xl font-bold text-primary mb-2">500+</h4>
                <p className="text-gray-700 font-medium mb-4">Profesionales Formados</p>
                <h4 className="text-3xl font-bold text-primary mb-2">50+</h4>
                <p className="text-gray-700 font-medium mb-4">Instituciones Colaboradoras</p>
                <h4 className="text-3xl font-bold text-primary mb-2">95%</h4>
                <p className="text-gray-700 font-medium">Satisfacción de Participantes</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrainingSection;

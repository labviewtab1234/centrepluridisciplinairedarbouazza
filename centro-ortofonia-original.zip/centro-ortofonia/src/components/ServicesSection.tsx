import { Brain, Baby, Users, Mic, BookOpen, Heart } from "lucide-react";

const ServicesSection = () => {
  const services = [
    {
      icon: Baby,
      title: "Trastornos del Desarrollo del Lenguaje",
      description: "Evaluación y tratamiento de retrasos del lenguaje, trastornos específicos del lenguaje (TEL) y dificultades en la comunicación temprana.",
      features: ["Estimulación temprana", "Desarrollo del vocabulario", "Estructuración del lenguaje"]
    },
    {
      icon: Brain,
      title: "Trastornos del Habla",
      description: "Intervención especializada en dislalias, disartrias, apraxias del habla y otros trastornos articulatorios.",
      features: ["Corrección de pronunciación", "Fluidez verbal", "Ritmo del habla"]
    },
    {
      icon: BookOpen,
      title: "Dificultades de Aprendizaje",
      description: "Apoyo en dislexia, disgrafía, discalculia y otros trastornos del aprendizaje escolar.",
      features: ["Lectoescritura", "Comprensión lectora", "Expresión escrita"]
    },
    {
      icon: Mic,
      title: "Trastornos de la Voz",
      description: "Rehabilitación de disfonías, nódulos vocales, y educación de la voz para profesionales.",
      features: ["Higiene vocal", "Técnicas respiratorias", "Proyección vocal"]
    },
    {
      icon: Users,
      title: "Trastornos de la Comunicación",
      description: "Intervención en TEA (Trastorno del Espectro Autista), mutismo selectivo y habilidades sociales.",
      features: ["Comunicación funcional", "Interacción social", "Sistemas alternativos"]
    },
    {
      icon: Heart,
      title: "Deglución y Alimentación",
      description: "Evaluación y tratamiento de disfagia, problemas de masticación y selectividad alimentaria.",
      features: ["Seguridad alimentaria", "Técnicas de deglución", "Adaptación de texturas"]
    }
  ];

  return (
    <section id="servicios" className="py-20 bg-primary/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">
            ESPECIALIDADES Y EXPERTICIA
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mt-2 mb-4">
            Nuestros Servicios
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Ofrecemos una amplia gama de servicios especializados en ortofonía,
            adaptados a las necesidades específicas de cada paciente
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 group"
              >
                <div className="w-14 h-14 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary transition-colors duration-300">
                  <Icon className="text-primary group-hover:text-white transition-colors duration-300" size={28} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {service.description}
                </p>
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-sm text-gray-700">
                      <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">
            ¿Necesitas más información sobre nuestros servicios?
          </p>
          <button className="bg-primary hover:bg-primary-dark text-white px-8 py-3 rounded-full transition-colors duration-300 font-medium">
            Consulta Gratuita
          </button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;

"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, Phone } from "lucide-react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { name: "INICIO", href: "/" },
    { name: "NOSOTROS", href: "#nosotros" },
    { name: "SERVICIOS", href: "#servicios" },
    { name: "ESPECIALISTAS", href: "#especialistas" },
    { name: "FORMACIONES", href: "#formaciones" },
    { name: "CONTACTO", href: "#contacto" }
  ];

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-3">
              <svg className="w-14 h-14" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="100" cy="50" r="8" fill="#67989f"/>
                <path d="M100 60 L100 140" stroke="#4a5568" strokeWidth="3"/>
                <path d="M80 80 Q60 90 60 110 T80 140" stroke="#67989f" strokeWidth="4" fill="none"/>
                <path d="M120 80 Q140 90 140 110 T120 140" stroke="#67989f" strokeWidth="4" fill="none"/>
                <path d="M75 85 Q100 70 125 85" stroke="#67989f" strokeWidth="3" fill="none"/>
                <path d="M75 135 Q100 150 125 135" stroke="#67989f" strokeWidth="3" fill="none"/>
              </svg>
              <div>
                <h1 className="text-xl font-bold text-gray-800">Cabinet Orthothérapie</h1>
                <p className="text-xs text-primary">Orthophonie - Psychomotricité - Psychologie</p>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="text-gray-700 hover:text-primary transition-colors duration-300 font-medium"
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center space-x-4">
            <Link
              href="#cita"
              className="bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full transition-colors duration-300 font-medium"
            >
              RESERVAR CITA
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 rounded-md hover:bg-gray-100"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="lg:hidden py-4 border-t">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                onClick={() => setIsMenuOpen(false)}
                className="block py-3 px-4 text-gray-700 hover:text-primary hover:bg-gray-50 transition-colors duration-300"
              >
                {item.name}
              </Link>
            ))}
            <Link
              href="#cita"
              onClick={() => setIsMenuOpen(false)}
              className="block mt-4 mx-4 text-center bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full transition-colors duration-300 font-medium"
            >
              RESERVAR CITA
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;

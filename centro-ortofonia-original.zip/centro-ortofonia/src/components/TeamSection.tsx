import { Mail, Phone, Linkedin } from "lucide-react";

const TeamSection = () => {
  const team = [
    {
      name: "Dra. Amina Darbouazza",
      role: "Directora y Ortofonista Principal",
      specialties: ["Trastornos del lenguaje", "Disfagia", "Autismo"],
      image: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?q=80&w=1974",
      description: "Más de 15 años de experiencia en el campo de la ortofonía. Especializada en intervención temprana y trastornos del neurodesarrollo."
    },
    {
      name: "Lic. Karima El Mansouri",
      role: "Ortofonista Especialista",
      specialties: ["Dislexia", "Trastornos del habla", "Voz"],
      image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?q=80&w=1974",
      description: "Experta en trastornos del aprendizaje y rehabilitación vocal. Formación continua en técnicas innovadoras."
    },
    {
      name: "Lic. Youssef Benali",
      role: "Ortofonista",
      specialties: ["TEA", "Comunicación aumentativa", "Deglución"],
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?q=80&w=1970",
      description: "Especializado en trastornos del espectro autista y sistemas alternativos de comunicación."
    },
    {
      name: "Dra. Salma Idrissi",
      role: "Neuropsicóloga",
      specialties: ["Evaluación neuropsicológica", "Rehabilitación cognitiva"],
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=2070",
      description: "Colaboradora en evaluaciones integrales y diseño de programas de intervención multidisciplinaria."
    }
  ];

  return (
    <section id="especialistas" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">
            COMPETENCIA Y EXPERIENCIA
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mt-2 mb-4">
            Nuestro Equipo Profesional
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Un equipo multidisciplinario altamente cualificado, comprometido con la excelencia
            en el cuidado y bienestar de nuestros pacientes
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {team.map((member, index) => (
            <div
              key={index}
              className="group"
            >
              <div className="relative overflow-hidden rounded-lg mb-4">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-80 object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex justify-center space-x-3">
                      <button className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors">
                        <Mail size={18} className="text-primary" />
                      </button>
                      <button className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors">
                        <Phone size={18} className="text-primary" />
                      </button>
                      <button className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors">
                        <Linkedin size={18} className="text-primary" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <h3 className="text-xl font-bold text-gray-900 mb-1">
                  {member.name}
                </h3>
                <p className="text-primary font-medium mb-3">
                  {member.role}
                </p>
                <p className="text-gray-600 text-sm mb-3">
                  {member.description}
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  {member.specialties.map((specialty, idx) => (
                    <span
                      key={idx}
                      className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TeamSection;

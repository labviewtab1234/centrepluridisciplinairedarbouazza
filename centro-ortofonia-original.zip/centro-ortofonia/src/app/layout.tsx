import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Centro Darbouazza - Ortofonía Especializada en Casablanca",
  description: "Centro especializado en el tratamiento de trastornos del habla, lenguaje, voz y deglución. Más de 15 años de experiencia en Casablanca.",
  keywords: "ortofonía, logopedia, trastornos del habla, trastornos del lenguaje, terapia del lenguaje, Casablanca, Marruecos, Darbouazza",
  authors: [{ name: "Centro Darbouazza" }],
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
    apple: "/favicon.svg",
  },
  openGraph: {
    title: "Centro Darbouazza - Ortofonía Especializada",
    description: "Centro especializado en el tratamiento de trastornos del habla y lenguaje en Casablanca",
    type: "website",
    locale: "es_ES",
    siteName: "Centro Darbouazza",
    images: [
      {
        url: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=2070",
        width: 1200,
        height: 630,
        alt: "Centro Darbouazza - Ortofonía Especializada",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Centro Darbouazza - Ortofonía Especializada",
    description: "Centro especializado en el tratamiento de trastornos del habla y lenguaje en Casablanca",
  },
  viewport: "width=device-width, initial-scale=1",
  robots: "index, follow",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
